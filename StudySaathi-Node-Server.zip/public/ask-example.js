/*
Example browser-side integration.
Include this file in your page or adapt the function to your existing frontend.
The form should have an input/textarea with id="question" and an element with id="answer".
*/

async function askStudySaathi(question, imageDataUrl = "", language = "Hindi") {
  const answerBox = document.getElementById("answer");
  if (answerBox) answerBox.textContent = "सोच रहा हूँ…";

  try {
    const response = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        image: imageDataUrl,
        language
      })
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed");
    if (answerBox) answerBox.textContent = data.answer;
    return data.answer;
  } catch (error) {
    if (answerBox) answerBox.textContent = error.message;
    throw error;
  }
}

// Example use:
// document.getElementById("askButton").addEventListener("click", () => {
//   askStudySaathi(document.getElementById("question").value);
// });
