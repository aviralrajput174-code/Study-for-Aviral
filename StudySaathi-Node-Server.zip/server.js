require("dotenv").config();

const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "12mb" }));

// Frontend files go in ./public (index.html, style.css, and browser JS).
app.use(express.static(path.join(__dirname, "public")));

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "StudySaathi AI server" });
});

app.post("/api/ask", async (req, res) => {
  try {
    if (!openai) {
      return res.status(503).json({
        error: "OPENAI_API_KEY is missing. Add it to the server's environment variables."
      });
    }

    const question = typeof req.body.question === "string"
      ? req.body.question.trim()
      : "";
    const image = typeof req.body.image === "string" ? req.body.image : "";
    const language = req.body.language === "English" ? "English" : "Hindi";

    if (!question && !image) {
      return res.status(400).json({
        error: "Please enter a question or upload a question image."
      });
    }

    const content = [];
    if (question) {
      content.push({
        type: "input_text",
        text: `Student's question: ${question}`
      });
    }

    // Optional image: send a data URL such as data:image/jpeg;base64,...
    if (image) {
      if (!/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(image)) {
        return res.status(400).json({
          error: "Image must be a PNG, JPEG, WEBP, or GIF data URL."
        });
      }
      content.push({ type: "input_image", image_url: image });
    }

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions:
        `You are StudySaathi AI, a helpful tutor for students in Classes 9–12 and college. ` +
        `Explain the answer step by step in ${language}. Use clear, student-friendly language. ` +
        `For maths and science, show the working. If the image/question is unclear, say what is unclear. ` +
        `Do not claim certainty when the question cannot be read.`,
      input: [{ role: "user", content }]
    });

    res.json({ answer: response.output_text || "Sorry, I could not generate an answer." });
  } catch (error) {
    console.error("POST /api/ask failed:", error.message);
    const status = error.status && Number.isInteger(error.status) ? error.status : 500;
    res.status(status >= 400 && status < 600 ? status : 500).json({
      error: status === 401
        ? "The server API key was rejected. Check OPENAI_API_KEY."
        : status === 429
          ? "The AI service limit was reached. Check your API billing/usage and try again."
          : "The server could not answer right now. Check the server logs and try again."
    });
  }
});

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) {
    return res.status(404).json({ error: "API route not found." });
  }
  res.sendFile(path.join(__dirname, "public", "index.html"), (err) => {
    if (err) next(err);
  });
});

app.listen(PORT, () => {
  console.log(`StudySaathi AI server running on port ${PORT}`);
});
