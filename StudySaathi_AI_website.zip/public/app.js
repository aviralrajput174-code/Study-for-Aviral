const $ = (id) => document.getElementById(id);
let selectedImage = null;
let english = false;

$("imageInput").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  if (file.size > 8 * 1024 * 1024) {
    alert("कृपया 8 MB से छोटी फोटो चुनें।");
    event.target.value = "";
    return;
  }
  if (!file.type.startsWith("image/")) {
    alert("कृपया image file चुनें।");
    event.target.value = "";
    return;
  }
  selectedImage = await resizeImage(file);
  $("imagePreview").src = selectedImage;
  $("imagePreviewWrap").classList.remove("hidden");
  $("uploadBox").classList.add("hidden");
});

function resizeImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const max = 1800;
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.86));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

$("removeImage").addEventListener("click", () => {
  selectedImage = null;
  $("imageInput").value = "";
  $("imagePreviewWrap").classList.add("hidden");
  $("uploadBox").classList.remove("hidden");
});

$("solveBtn").addEventListener("click", async () => {
  const question = $("question").value.trim();
  if (!question && !selectedImage) {
    $("question").focus();
    showError("पहले सवाल लिखें या उसकी फोटो अपलोड करें।");
    return;
  }
  const btn = $("solveBtn");
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner">◌</span> AI सोच रहा है…';
  $("resultBadge").textContent = "WORKING";
  $("result").innerHTML = '<p>आपके सवाल को पढ़कर आसान भाषा में समझाया जा रहा है। इसमें कुछ सेकंड लग सकते हैं…</p>';
  try {
    const response = await fetch("/api/solve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        image: selectedImage,
        language: $("language").value,
        level: $("level").value,
        detail: "step-by-step"
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "उत्तर नहीं मिल पाया।");
    renderAnswer(data.answer || "उत्तर खाली मिला।");
    $("resultBadge").textContent = "ANSWER READY";
  } catch (error) {
    showError(error.message || "कनेक्शन में समस्या आई।");
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span>✦</span> AI से समझाएँ <span class="arrow">→</span>';
  }
});

function renderAnswer(text) {
  const container = $("result");
  container.replaceChildren();
  text.split(/\n+/).forEach(line => {
    const trimmed = line.trim();
    if (!trimmed) return;
    if (/^(#{1,4}\s|step\s*\d|चरण\s*\d|final answer|अंतिम उत्तर|समाधान|उत्तर:|मुख्य concept)/i.test(trimmed)) {
      const h = document.createElement("h4");
      h.textContent = trimmed.replace(/^#{1,4}\s*/, "");
      container.appendChild(h);
    } else {
      const p = document.createElement("p");
      p.textContent = trimmed.replace(/^\*\*(.*?)\*\*$/, "$1").replace(/^\*\s?/, "• ");
      container.appendChild(p);
    }
  });
}
function showError(message) {
  $("resultBadge").textContent = "NOTICE";
  $("result").replaceChildren();
  const h = document.createElement("h4");
  h.textContent = "अभी उत्तर नहीं मिल पाया";
  const p = document.createElement("p");
  p.textContent = message;
  $("result").append(h, p);
}

$("langBtn").addEventListener("click", () => {
  english = !english;
  $("langBtn").textContent = english ? "हिन्दी" : "English";
  document.documentElement.lang = english ? "en" : "hi";
  document.querySelector(".hero-copy h1").innerHTML = english
    ? 'Make learning<br><span>simple and smart.</span>'
    : 'पढ़ाई को बनाओ<br><span>आसान और स्मार्ट।</span>';
  document.querySelector(".hero-copy>p").textContent = english
    ? "From Class 9 to Graduation, MBA and M.Com — type a question or upload a photo and get a step-by-step explanation in simple language."
    : "Class 9 से Graduation, MBA और M.Com तक — सवाल लिखो या फोटो डालो और आसान भाषा में step-by-step explanation पाओ।";
});

fetch("/api/status").then(r => r.json()).then(status => {
  $("statusDot").style.color = status.configured ? "#86efac" : "#fbbf24";
  $("statusDot").title = status.configured ? "AI configured" : "AI needs server API key";
}).catch(() => {
  $("statusDot").style.color = "#f87171";
});