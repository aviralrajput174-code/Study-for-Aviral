import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
const app = express();
const port = process.env.PORT || 3000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: "12mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/status", (_req, res) => {
  res.json({ configured: Boolean(client), model: process.env.OPENAI_MODEL || "gpt-4.1-mini" });
});

app.post("/api/solve", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({
        error: "AI अभी configure नहीं है। Server पर OPENAI_API_KEY सेट करें, फिर server restart करें।"
      });
    }

    const { question, image, language = "Hindi", level = "School/College", detail = "step" } = req.body || {};
    if ((!question || !question.trim()) && !image) {
      return res.status(400).json({ error: "सवाल लिखें या उसकी फोटो अपलोड करें।" });
    }

    const instructions = `You are StudySaathi, a careful tutor for learners from Class 9 through undergraduate, MBA and M.Com.
Answer in ${language}. The student's level/course is ${level}. Explain in accessible language, define difficult terms, and teach rather than only giving a final answer.
For math/physics/chemistry, show clear steps and units where relevant. For biology, explain concepts accurately. For MBA/M.Com, structure business/accounting/management answers with assumptions, formulas or examples where useful.
If the photo is blurry or the question is incomplete, say exactly what is unclear and ask for a clearer image rather than inventing text.
Format the answer with: (1) what the question asks, (2) step-by-step explanation, (3) final answer, (4) quick check or key concept. Be honest about uncertainty. Do not claim to have checked a textbook or source unless you actually have.`;

    const content = [];
    if (question?.trim()) content.push({ type: "input_text", text: question.trim() });
    if (image) {
      if (typeof image !== "string" || !/^data:image\/(png|jpe?g|webp|gif);base64,/.test(image)) {
        return res.status(400).json({ error: "फोटो PNG, JPG, WEBP या GIF में अपलोड करें।" });
      }
      content.push({ type: "input_image", image_url: image, detail: "high" });
    }
    content.push({ type: "input_text", text: `Explanation preference: ${detail}. Solve the question shown/written above.` });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions,
      input: [{ role: "user", content }]
    });
    res.json({ answer: response.output_text || "माफ़ कीजिए, इस बार उत्तर नहीं मिला। फिर कोशिश करें।" });
  } catch (err) {
    console.error("Solve error:", err?.message || err);
    const message = err?.status === 401
      ? "API key स्वीकार नहीं हुई। Server की API key जाँचें।"
      : err?.status === 429
      ? "AI की usage limit या billing limit पूरी हो सकती है। API dashboard में usage जाँचें।"
      : "AI से उत्तर लेते समय समस्या आई। थोड़ी देर बाद फिर कोशिश करें।";
    res.status(500).json({ error: message });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(port, () => console.log(`StudySaathi AI running on http://localhost:${port}`));